// Network-first navigation: never cache private bookings or API responses.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', event => {
  if (event.request.mode === 'navigate') {
    event.respondWith(fetch(event.request).catch(() => new Response('الاتصال بالإنترنت مطلوب لعرض الحجوزات.', {status:503,headers:{'Content-Type':'text/plain; charset=utf-8'}})));
  }
});
