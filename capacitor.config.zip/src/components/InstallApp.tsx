import { useEffect, useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';

type InstallPrompt = Event & { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> };

/** A visible installation entry point even when the browser does not emit beforeinstallprompt. */
export function InstallApp() {
  const [deferred, setDeferred] = useState<InstallPrompt | null>(null);
  const [open, setOpen] = useState(false);
  const [installed, setInstalled] = useState(false);
  const [ios, setIos] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => {
    const onPrompt = (event: Event) => { event.preventDefault(); setDeferred(event as InstallPrompt); };
    const onInstalled = () => { setInstalled(true); setOpen(false); setDeferred(null); };
    window.addEventListener('beforeinstallprompt', onPrompt);
    window.addEventListener('appinstalled', onInstalled);
    setIos(/iPad|iPhone|iPod/.test(navigator.userAgent));
    setInstalled(window.matchMedia('(display-mode: standalone)').matches || Boolean((navigator as Navigator & { standalone?: boolean }).standalone));
    // Show guidance on the first visit, but keep a permanent manual entry point afterward.
    if (!sessionStorage.getItem('angezly-install-intro-seen')) {
      setOpen(true);
      sessionStorage.setItem('angezly-install-intro-seen', 'yes');
    }
    return () => { window.removeEventListener('beforeinstallprompt', onPrompt); window.removeEventListener('appinstalled', onInstalled); };
  }, []);
  if (installed) return null;
  const install = async () => {
    if (!deferred) return;
    try {
      await deferred.prompt();
      const result = await deferred.userChoice;
      if (result.outcome === 'accepted') { setDeferred(null); setOpen(false); }
    } catch { setError('تعذّر فتح التثبيت المباشر. استخدم خطوات المتصفح الموضحة أدناه.'); }
  };
  return <div dir="rtl" style={{position:'fixed',bottom:16,left:16,zIndex:80,maxWidth:'calc(100vw - 32px)'}}>
    {!open ? <button type="button" onClick={() => setOpen(true)} aria-label="كيفية تثبيت أنجزلي على الموبايل" style={{display:'flex',alignItems:'center',gap:8,background:'#0e9387',color:'white',padding:'12px 16px',borderRadius:30,boxShadow:'0 6px 24px #0003',fontWeight:700}}><Smartphone size={18}/> نزّل أنجزلي</button> :
      <aside role="dialog" aria-label="تثبيت تطبيق أنجزلي" style={{width:360,maxWidth:'calc(100vw - 32px)',background:'white',border:'1px solid #b8ddd5',borderRadius:18,padding:18,boxShadow:'0 8px 32px #0003'}}>
        <button type="button" aria-label="إغلاق نافذة التثبيت" onClick={() => setOpen(false)} style={{float:'left'}}><X size={20}/></button>
        <h2 style={{fontSize:18,fontWeight:800,marginBottom:8}}>أنجزلي على شاشة موبايلك 📱</h2>
        <p style={{fontSize:14,lineHeight:1.8,marginBottom:12}}>ثبّت الموقع وافتحه من أيقونة التطبيقات بدل ما تدور على اللينك كل مرة.</p>
        {deferred ? <button type="button" onClick={() => void install()} style={{display:'flex',alignItems:'center',gap:8,background:'#0e9387',color:'white',padding:'12px 16px',borderRadius:12,fontWeight:700}}><Download size={18}/> تثبيت أنجزلي الآن</button> : <div style={{background:'#f0faf7',borderRadius:12,padding:12,fontSize:13,lineHeight:1.9}}>{ios ? <>على آيفون: افتح الرابط في <b>Safari</b>، اضغط <b>مشاركة ⬆</b> ثم <b>إضافة إلى الشاشة الرئيسية</b>، وبعدها <b>إضافة</b>.</> : <>على أندرويد: افتح الرابط في <b>Chrome</b>، اضغط <b>⋮</b> ثم <b>تثبيت التطبيق</b> أو <b>إضافة إلى الشاشة الرئيسية</b>. لو فتحته داخل واتساب أو فيسبوك، اختار <b>فتح في Chrome</b> أولًا.</>}</div>}
        {error && <p role="alert" style={{color:'#b91c1c',fontSize:13,marginTop:10}}>{error}</p>}
        <button type="button" onClick={() => setOpen(false)} style={{marginTop:12,fontSize:13,textDecoration:'underline'}}>كمّل من المتصفح</button>
      </aside>}
  </div>;
}
